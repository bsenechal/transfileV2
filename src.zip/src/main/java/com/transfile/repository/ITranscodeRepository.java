package com.transfile.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.transfile.model.Transcode;

public interface ITranscodeRepository extends CrudRepository<Transcode, Long> {
    
    @Override
    public List<Transcode> findAll();
}
