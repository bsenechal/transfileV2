package com.transfile.normalisation.transcodage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transfile.model.LogType;
import com.transfile.model.Transcode;
import com.transfile.repository.ITranscodeRepository;

@Service
@Transactional
public class TranscodeService implements ITranscodeService{
    
	 /**
     * Map de toutes les valeurs de transcodage.
     */
    private final Map<LogType, Map<String, String>> transcodageContainer = new HashMap<LogType, Map<String, String>>();

    
    @Autowired
    private ITranscodeRepository transcodeRepository;
    
    @Override
    public String getSOBNormalise(String valeurDB)
            throws TranscodeException {
        return getValeurNormalise(LogType.SOB, valeurDB);
    }
    
    @Override
    public String getSUBNormalise(String valeurDB)
            throws TranscodeException {
        return getValeurNormalise(LogType.SUB, valeurDB);
    }
    
    @Override
    public String getMatchingNormalise(String valeurDB)
            throws TranscodeException {
        return getValeurNormalise(LogType.matching, valeurDB);
    }
    
    @Override
    public String getChargebackNormalise(String valeurDB)
            throws TranscodeException {
        return getValeurNormalise(LogType.chargeback, valeurDB);
    }
    
    @Override
    public String getWalletNormalise(String valeurDB)
            throws TranscodeException {
        return getValeurNormalise(LogType.wallet, valeurDB);
    }
    
    @Override
    public String getOperationNormalise(String valeurDB)
            throws TranscodeException {
        return getValeurNormalise(LogType.operation, valeurDB);
    }
    
    @Override
    public String getTransactionNormalise(String valeurDB)
            throws TranscodeException {
        return getValeurNormalise(LogType.transaction, valeurDB);
    }

    private String getValeurNormalise(LogType logType, String valeurDB) throws TranscodeException {

        if (valeurDB == null) {
            return null;
        }

        final Map<String, String> logTypes = transcodageContainer.get(logType);

        if (logTypes != null) {
           return logTypes.get(valeurDB);
        }

        throw new TranscodeException("LogType : " + logType.getValue() + ": la valeur " + valeurDB
                + " n'a pas de correspondence normalisée.");
    }
    
    @PostConstruct
    private void initialize() {
        final List<Transcode> transcodages = transcodeRepository.findAll();

        for (final Transcode transcodage : transcodages) {
        	
             Map<String, String> logtypes = transcodageContainer.get(transcodage.getLogType());
             
             
             if (logtypes == null) {
            	 logtypes = new HashMap<String, String>();
                 transcodageContainer.put(transcodage.getLogType(), logtypes);
             }
        	
             logtypes.put(transcodage.getDbValue(), transcodage.getConfValue());
        }
    }


    
}
