package com.transfile.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transfile.model.Configuration;
import com.transfile.repository.IConfigurationRepository;

@Service
@Transactional
public class ConfigurationService implements IConfigurationService{
    
    @Autowired
    private IConfigurationRepository configurationRepository;
    
    public List<Configuration> findAll() {
        return configurationRepository.findAll();
    }
    
    public List<Configuration> findByLogType(String logType) {
        return configurationRepository.findByLogType(logType);
    }
}
