package com.transfile.model.log_type;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.transfile.model.Client;
import com.transfile.model.Configuration;
import com.transfile.model.LogType;
import com.transfile.normalisation.transcodage.ITranscodeService;

@Component
public class SUBAborep extends ALogType {
	private static final String SUBUBZ = "SUBUBZ";
	private static final String ABOREPNET = "ABOREPNET";
	@Autowired
	private ITranscodeService transcodeService;

	@Override
	public String getContent() {
		List<Configuration> configs = configurationService
				.findByLogType(LogType.SUB.getValue());
		String fileContent = EMPTY;
		Client client;
		String defaultZipName;
		String forcedValue;
		String forcedExtension;

		for (Configuration config : configs) {
			client = config.getClient();
			defaultZipName = config.getNameZip() + config.getOccurence()
					+ transcodeService.getSUBNormalise(config.getExtention());

			forcedValue = config.getForcedFileName();

			forcedExtension = null;

			// Il manque le SIPS_ALIAS
			fileContent = SUBUBZ
					+ DOT
					+ ABOREPNET
					+ DOT
					+ client.getSipsAlias()
					+ DOT
					+ ASTERIX
					+ COLON
					+ ABOREPNET
					+ COLON
					+ client.getMerchantFtp()
					+ checkForcedValue(config, forcedValue, forcedExtension,
							defaultZipName) + COLON
					+ transcodeService.getSUBNormalise(client.getProtocol());

			String.join(System.getProperty("line.separator"), fileContent);
		}

		fileContent = fileContent.replace(NULL, EMPTY);

		return fileContent;
	}

}
