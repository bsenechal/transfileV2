package com.transfile.model.log_type;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.transfile.model.Client;
import com.transfile.model.Configuration;
import com.transfile.model.LogType;
import com.transfile.normalisation.transcodage.ITranscodeService;

@Component
public class Matching extends ALogType {

	private static final String UBZ_MATCHING = "ubz-matching.jrb-report";

	private static final String FTP_B = "ftp_b";

	@Autowired
	private ITranscodeService transcodeService;

	@Override
	public String getContent() {
		List<Configuration> configs = configurationService
				.findByLogType(LogType.matching.getValue());
		String fileContent = EMPTY;
		Client client;
		String defaultZipName;
		String forcedValue;
		String forcedExtension;

		for (Configuration config : configs) {
			client = config.getClient();
			defaultZipName = config.getNameZip()
					+ config.getOccurence()
					+ transcodeService.getMatchingNormalise(config
							.getExtention()) + COLON + config.getNameFile()
					+ config.getOccurence();

			forcedValue = config.getForcedZipName()
					+ config.getForcedFileName();

			forcedExtension = config.getForcedFileName();

			fileContent = UBZ_MATCHING
					+ DOT
					+ transcodeService.getMatchingNormalise(client
							.getBankName())
					+ DASH
					+ client.getMerchantId()
					+ DASH
					+ client.getSipsAlias()
					+ DOT
					+ ASTERIX
					+ COLON
					+ config.getProfile()
					+ COLON
					+ client.getMerchantFtp()
					+ DOT
					+ FTP_B
					+ DOT
					+ checkForcedValue(config, forcedValue, forcedExtension,
							defaultZipName)
					+ DOT
					+ transcodeService.getMatchingNormalise(config
							.getDateFormat())
					+ COLON
					+ transcodeService.getMatchingNormalise(client
							.getProtocol())
					+ COLON
					+ transcodeService.getMatchingNormalise(String
							.valueOf(config.getDeleteFlag()))
					+ COLON
					+ transcodeService.getMatchingNormalise(String
							.valueOf(config.getMultiple())) + COLON;

			String.join(System.getProperty("line.separator"), fileContent);
		}

		fileContent = fileContent.replace(NULL, EMPTY);

		return fileContent;
	}

}
