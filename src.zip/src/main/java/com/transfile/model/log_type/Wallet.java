package com.transfile.model.log_type;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.transfile.model.Client;
import com.transfile.model.Configuration;
import com.transfile.model.LogType;
import com.transfile.normalisation.transcodage.ITranscodeService;
import com.transfile.service.IConfigurationService;

@Component
public class Wallet extends ALogType {

	private static final String UBZ_WALLET = "ubz-wallet.expiring";

	private static final String FTP_B = "ftp_b";

	@Autowired
	private IConfigurationService configurationService;

	@Autowired
	private ITranscodeService transcodeService;

	@Override
	public String getContent() {
		List<Configuration> configs = configurationService
				.findByLogType(LogType.wallet.getValue());
		String fileContent = EMPTY;
		Client client;

		for (Configuration config : configs) {
			client = config.getClient();
			String defaultZipName;
			String forcedValue;
			String forcedExtension;

			defaultZipName = config.getNameZip()
					+ config.getOccurence()
					+ DOT
					+ transcodeService
							.getWalletNormalise(config.getExtention()) + COLON
					+ config.getNameFile() + config.getOccurence();

			forcedValue = config.getForcedZipName() + COLON
					+ config.getForcedZipName();

			forcedExtension = config.getForcedFileName();

			fileContent = UBZ_WALLET
					+ client.getMerchantId()
					+ DASH
					+ client.getSipsAlias()
					+ DOT
					+ ASTERIX
					+ COLON
					+ config.getProfile()
					+ COLON
					+ client.getMerchantFtp()
					+ DOT
					+ FTP_B
					+ DOT
					+ checkForcedValue(config, forcedValue, forcedExtension,
							defaultZipName)
					+ DOT
					+ transcodeService.getWalletNormalise(config
							.getDateFormat())
					+ COLON
					+ transcodeService.getWalletNormalise(client.getProtocol())
					+ COLON
					+ transcodeService.getWalletNormalise(String.valueOf(config
							.getDeleteFlag()))
					+ COLON
					+ transcodeService.getWalletNormalise(String.valueOf(config
							.getMultiple())) + COLON;

			String.join(System.getProperty("line.separator"), fileContent);
		}

		fileContent = fileContent.replace(NULL, EMPTY);

		return fileContent;
	}
}
