package com.transfile.model.log_type;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.transfile.model.Client;
import com.transfile.model.Configuration;
import com.transfile.model.LogType;
import com.transfile.normalisation.transcodage.ITranscodeService;

@Component
public class SOBOffbatcdftor extends ALogType {
	private static final String UBZIP = "ubzip:OFFUBZ.OFFBAREP";

	private static final String FTP_B = "ftp_b";

	@Autowired
	private ITranscodeService transcodeService;

	@Override
	public String getContent() {
		List<Configuration> configs = configurationService
				.findByLogType(LogType.SOB.getValue());
		String fileContent = EMPTY;
		Client client;
		String defaultZipName;
		String forcedValue;
		String forcedExtension;

		for (Configuration config : configs) {
			client = config.getClient();
			defaultZipName = config.getNameZip()
					+ config.getOccurence()
					+ transcodeService.getSOBNormalise(String.valueOf(config
							.getOccurence()));

			forcedValue = config.getForcedZipName() + COLON
					+ config.getForcedFileName();

			forcedExtension = config.getForcedFileName() + COLON
					+ config.getNameFile();

			// Il manque le SIPS_ALIAS
			fileContent = UBZIP
					+ DOT
					+ client.getSipsAlias()
					+ COLON
					+ client.getMerchantFtp()
					+ DOT
					+ FTP_B
					+ DOT
					+ checkForcedValue(config, forcedValue, forcedExtension,
							defaultZipName) + COLON
					+ transcodeService.getSOBNormalise(client.getProtocol());

			String.join(System.getProperty("line.separator"), fileContent);
		}

		fileContent = fileContent.replace(NULL, EMPTY);

		return fileContent;
	}
}
