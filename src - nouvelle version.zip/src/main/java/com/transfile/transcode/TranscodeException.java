/**
 *
 */
package com.transfile.transcode;

/**
 * Exception indiquant que une valeur fournisseur ne peut pas être normalisée.
 *
 * @author 636841
 *
 */
public class TranscodeException extends RuntimeException {
    private static final long serialVersionUID = 7529783282125060533L;

    /**
     * @param message
     */
    public TranscodeException(final String message) {
    }

}
